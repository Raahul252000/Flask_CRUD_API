from app.main import db


class Ksolves(db.Model):
    k_id = db.Column(db.Integer(),primary_key=True)
    emp_name = db.Column(db.String(length=100),nullable=False)
    email = db.Column(db.String(length=100),nullable=False)

    def __repr__(self):
        return f"Id: {self.k_id},Employee Name: {self.emp_name}"