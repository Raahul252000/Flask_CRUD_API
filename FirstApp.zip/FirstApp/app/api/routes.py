from flask import Blueprint,jsonify
from app.services.employee import employee
route_bp = Blueprint("routes",__name__)


@route_bp.route("/")
def is_server_up():
    return jsonify({"msg":"server is running"})

@route_bp.route("/addemp",methods=['POST'])
def create_emp():
    obj = employee()
    return obj.create_emp()


@route_bp.route("/getemp/<int:id>",methods=['GET'])
def get_emp(id):
    obj = employee()
    return obj.get_emp(id=id)

@route_bp.route("/getall",methods=['GET'])
def get_all_emp():
    obj = employee()
    return obj.getall()

@route_bp.route("/del_emp/<int:id>",methods=['DELETE'])
def delete_emp(id):
    obj = employee()
    return obj.delete_emp(id=id)

@route_bp.route("/update/<int:id>",methods=['PATCH'])
def update_data_emp(id):
    obj = employee()
    return obj.update_emp(id)
