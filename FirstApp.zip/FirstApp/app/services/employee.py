from app.model.mydatabase import Ksolves
from flask import request,jsonify
from app.main import db


class employee():
    def create_emp(self):
        try:
            data = request.json
            eid = data["k_id"]
            name = data["emp_name"]
            email = data["email"]
            new_user = Ksolves(k_id=eid,emp_name=name,email=email)
            db.session.add(new_user)
            db.session.commit()

            return jsonify({"msg":"employee added successfully."})

        except Exception as e:
            db.session.rollback()
            return jsonify({"error":f"{e}"}),500

    def get_emp(self,id):
        try:
            print(id)
            data = Ksolves.query.filter_by(k_id=id).first()
            emp = {"emp_id":data.k_id,"Name":data.emp_name,"email":data.email}
            return jsonify({"Employee":emp})

        except Exception as e:
            return jsonify({"Error: ":f"{e}"})

    def getall(self):
        try:
            datas = Ksolves.query.all()
            emp_list = [{"emp_id":data.k_id,"Name":data.emp_name,"email":data.email} for data in datas]
            return jsonify({"all employess":emp_list})

        except Exception as e:
            return jsonify({"Error": f"{e}"})

    def delete_emp(self,id):
        try:
            emp = Ksolves.query.get(id);
            db.session.delete(emp)
            db.session.commit()
            return jsonify({"msg": "employee deleted successfully"})

        except Exception as e:
            return jsonify({"msg":f"{e}"})

    def update_emp(self,id):
        try:
            new_data = request.json
            orig_emp = Ksolves.query.get(id)
            # orig_emp.k_id = new_data["k_id"]
            orig_emp.emp_name = new_data["emp_name"]
            orig_emp.email = new_data["email"]

            db.session.commit()
            return jsonify({"msg": "employee detail updated successfully"})

        except Exception as e:
            return jsonify({"msg":f"{e}"})

