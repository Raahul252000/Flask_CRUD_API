from flask import Flask
from flask_sqlalchemy import SQLAlchemy


myapp = Flask(__name__)

myapp.config['SQLALCHEMY_DATABASE_URI'] = 'postgresql://python:admin@localhost:5432/class'
db = SQLAlchemy(myapp)

