from app.main import myapp
from app.api.routes import route_bp

myapp.register_blueprint(route_bp)

if __name__ == '__main__':
    # db.create_all()
    myapp.run(host="0.0.0.0",port=3002,debug=True)